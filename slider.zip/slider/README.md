# Full-Screen Responsive Image Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/solygambas/pen/JjEoEdb](https://codepen.io/solygambas/pen/JjEoEdb).

Based on [Full Screen Responsive Image Slider](https://www.youtube.com/watch?v=wWWNrANNO1k) by Brad Traversy (2019).

---
Want to collaborate? [Hire me](http://bit.ly/sg-pro)

[Twitter](https://twitter.com/solygambas) | [GitHub](https://github.com/solygambas) | [Dribbble](https://dribbble.com/solygambas)

